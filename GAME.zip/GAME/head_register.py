from tkinter import *
#import dashboard_page
import guess_database
import head_login
from tkinter import messagebox


class Head_register:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('1000x550+100+30')
        self.window.title('BILLING SOFTWARE DEVELOPED BY AMAN KUMAR')
        self.window.configure(background="blue")

        #ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY
        
        self.background_img_lft=PhotoImage(file="Images/question_img.png")
        self.img_left=Label(self.window,
                           image=self.background_img_lft).place(x=0,y=0)

        #--------------HEADIN--GUESS THE NUMBER----------------
        
        self.window.title=Label(self.window,text="GUESS THE NUMBER BETWEEN 00-100",bg="#074463",borderwidth=10,
                                        relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=2,y=6,width=1000)
    
        #------------------HEADING--SHOP NAME----------------
        self.window.title=Label(self.window,text="HEAD REGISTER",bg="#074463",borderwidth=10,
                                relief=GROOVE,fg="white",font=("times new roman",26,"bold"),pady=2).place(x=0,y=75,width=1000)
        #REGISTER HERE INFORMED
        self.window.title=Label(self.window,text="REGISTER HERE....",bg="#1701A1",borderwidth=10,
                                relief=GROOVE,fg="white",font=("times new roman",24,"bold"),pady=2).place(x=150,y=160,width=455)
        
        #FUNCTION CREATED FOR WIDGETS
    def head_reg_main(self):
        #textvariable
        self.head_reg_a=StringVar()
        self.head_reg_b=StringVar()
        self.head_reg_c=StringVar()
        #USER NAME WIDGET
        self.head_name=Label(self.window, text="Your Name",font=('arial',24,'bold'),
                                bg="#7B004E",fg='white').place(x=370,y=250)

        #ENTERY FIELD OF NAME WIDGET
        self.head_name_ent_field=Entry(self.window,borderwidth=10,textvariable=self.head_reg_a,font=('arial',24,'bold'),
                                      bg="white",fg='black').place(x=570,y=245,width=270)

        #USER PHONE MOBILE
        self.head_phone=Label(self.window, text="Email",font=('arial',24,'bold'),
                                bg="#7B004E",fg='white').place(x=370,y=320)

        #ENTERY PHONE MOBILE WIDGET
        self.head_phone_ent_field=Entry(self.window,borderwidth=10,textvariable=self.head_reg_b,font=('arial',24,'bold'),
                                      bg="white",fg='black').place(x=570,y=310,width=270)

        #EMAIL WIDGET
        self.head_email_emp_pwd=Label(self.window, text='Password',width=8,font=('arial',24,'bold'),
                           bg="#7B004E",fg='white').place(x=370,y=390)

        #ENTERY FIELD OF EMAIL WIDGET
        self.head_email_emp_pwd_ent_field=Entry(self.window,borderwidth=10,textvariable=self.head_reg_c,font=('arial',24,'bold'),
                                     bg="white",fg='black').place(x=570,y=380,width=270)

        #REGISTER BUTTON WIDGET
        self.head_reg_button=Button(self.window, text='Register',width=10,height=1,border=10,command=self.h_register_yr_slf,borderwidth=8,font=('arial',18),
                                 background="#CC012B",foreground='white',activebackground="#1701A1").place(x=530,y=465)


        self.abt_prd_prv_button=Button(self.window, text='Back',width=10,height=1,border=10,borderwidth=8,font=('arial',18),
                                 background="#00E856",foreground='white',command=self.goto_h_login_page,activebackground="#1701A1").place(x=860,y=150,width=130)

        
    #FUNCTION FOR GO TO LOGIN PAGE
    def goto_h_login_page(self):
        m=messagebox.askquestion("Exit","Do You Want To Go To Login Window")
        if m=='yes':
            self.window.destroy()
            log=head_login.Head_login()
            log.head_login_main()

    def h_register_yr_slf(self):
        #-----------SHOWS MESSAGE FOR INSERTED SUCCESSFULLY------------
        i=self.head_reg_a.get()
        j=self.head_reg_b.get()
        k=self.head_reg_c.get()
        if self.head_reg_a.get()=="" or  self.head_reg_b.get()=="" or self.head_reg_c.get()=="":
            messagebox.showwarning("Warning","Empty Box")
        else:
            u=guess_database.h_register(i,j,k)
            print(u)
            if u == True:
                print('Successfully Registered')
                messagebox.showwarning("Success"," Registered Successfully")
                self.window.destroy()
                log=head_login.Head_login()
                log.head_login_main()
            elif u == False:
                print('Not Registered')
                messagebox.showwarning("Warning","Not Registered")
        
if __name__ == '__main__':
    reg=Head_register()
    reg.head_reg_main()

