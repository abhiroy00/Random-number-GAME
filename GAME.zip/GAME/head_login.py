from tkinter import *
from tkinter import messagebox
import head_register
import guess_database
import head_dashboard
import bolo



class Head_login:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('1000x520+110+40')
        self.window.title('GUESS THE NUMBER DEVELOPED BY AMAN KUMAR HEAD LOGIN WINDOW')
        self.window.configure(background="blue")


        #ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY
        
        self.background_img=PhotoImage(file="Images/question_img.png")
        self.img_leftt=Label(self.window,
                           image=self.background_img).place(x=0,y=0)

        self.background_img_lft=PhotoImage(file="Images/user_login.png")#user_login
        self.img_left=Label(self.window,
                           image=self.background_img_lft).place(x=500,y=90)

        #--------------HEADIN--GUESS THE NUMBER----------------
        
        self.window.title=Label(self.window,text="GUESS THE NUMBER BETWEEN 00-100",bg="#074463",borderwidth=10,
                                        relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=2,y=6,width=1000)
    
        #------------------HEADING--SHOP NAME----------------
        '''self.window.title=Label(self.window,text="Try Your Luck",bg="#074463",borderwidth=10,
                                relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=0,y=75,width=1000)'''

        
        
        #FUNCTION CREATED FOR WIDGETS
    def head_login_main(self):
        self.head_a=StringVar()
        self.pwd_b=StringVar()

        
        #HEAD NAME WIDGET
        self.head_name=Label(self.window, text="User Name",font=('arial',24,'bold'),bg="#7B004E",fg='white')
        self.head_name.place(x=320,y=220)

        #ENTERY FIELD OF HEAD USERNAME WIDGET
        self.head_name_ent_field=Entry(self.window,borderwidth=10,textvariable=self.head_a,font=('arial',24,'bold'),
                                      bg="white",fg='black').place(x=520,y=215,width=400)

        #PASSWORD WIDGET
        self.head_pwd=Label(self.window, text='Password',width=8,font=('arial',24,'bold'),
                           bg="#7B004E",fg='white').place(x=320,y=285)

        #ENTERY FIELD OF PASSWORD WIDGET
        self.head_pwd_ent_field=Entry(self.window,borderwidth=10,textvariable=self.pwd_b,font=('arial',24,'bold'),
                                     bg="white",fg='black').place(x=520,y=280,width=400)

        #REGISTER BUTTON WIDGET
        self.head_reg_button=Button(self.window, text='Register Now...',width=10,height=1,command=self.goto_reg_page,border=10,borderwidth=6,font=('arial',8),
                                 background="#009700",foreground='white',activebackground="#1701A1").place(x=610,y=340,width=120)

        
        #LOGIN BUTTON WIDGET
        self.head_login_button=Button(self.window, text='Login',width=10,height=1,command=self.login,border=10,borderwidth=8,font=('arial',18),
                                 background="#CC012B",foreground='white',activebackground="#1701A1").place(x=550,y=375)
        
    #FUNCTION FOR GO TO DASH BOARDPAGE
    def login(self):
        a=self.head_a.get()
        b=self.pwd_b.get()
        logg=guess_database.head_login(a,b)
        print(logg)
        if self.head_a.get()=="" or self.pwd_b.get()=="":
            messagebox.showinfo("Alert","Empty Boxes")
        else:


            if logg:
                messagebox.showinfo("Success","Successfully Login")
                bolo.say(f"log in Successfully")
                self.window.destroy()
                dash_board=head_dashboard.Head_dashboard()
                dash_board.head_dashboard_main()

            else:
                messagebox.showinfo("Alert","Username and Password Not Matched")
#===================================================================================

            #Try Again Throught This Way
        '''elif c==self.usr_a.get() and c==self.pwd_b.get():
            messagebox.showinfo("Success","Successfully Login")
            self.window.destroy()
            calling_dashboard_module=dashboard_page.dashboard()
            calling_dashboard_module.dashboard_main()

        else:
            messagebox.showinfo("Alert","Username and Password Not Matched")
            print("user password not matched")'''

#=======================================================================================










        
#==================================================================================================
            #SIMPLE LOGIN 
        
        '''if self.emp_a.get()=="" or self.pwd_b.get()=="":
            messagebox.showinfo("Alert","Empty Boxes")

        elif self.emp_a.get()=='amansham12345@gmail.com' and self.pwd_b.get()=='indian':
            messagebox.showinfo("Success","Successfully Login")
            self.window.destroy()
            calling_dashboard_module=dashboard_page.dashboard()
            calling_dashboard_module.dashboard_main()
            
        else:
            messagebox.showinfo("Alert","Username and Password Not Matched")
            print("user password not matched")'''

#==================================================================================================            

            
            
        
            
        
    #FUNCTION FOR GO TO REGISTER PAGE
    def goto_reg_page(self):
        ask=messagebox.askquestion("Alert","Do You Want To Register")
        if ask=='yes':
            self.window.destroy()
            reg=head_register.Head_register()
            reg.head_reg_main()
        
if __name__ == '__main__':
    log=Head_login()
    log.head_login_main()
    log.window.mainloop()

