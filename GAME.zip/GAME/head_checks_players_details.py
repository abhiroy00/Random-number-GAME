from tkinter import *
from tkinter.ttk import Treeview
from tkinter import messagebox
import guess_database
import head_dashboard
class Heads_checks_about_player:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('850x600+250+20')
        self.window.title('THIS GAME IS DEVELOPED BY AMAN AND ABHISHEK')
        self.window.configure(background="blue")

        #-----------------ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY--------------------
        self.background_img_lft = PhotoImage(file="Images/img_guess.png")
        self.img_left = Label(self.window, image=self.background_img_lft).place(x=0, y=0)
        
        '''self.background_img_lft=PhotoImage(file="Images/about_product_page.png")
        self.img_left=Label(self.window,
                           image=self.background_img_lft).place(x=0,y=0)'''


        #--------------------------HEADING----------------------------
        
        self.window.title = Label(self.window, text="GUESS THE NUMBER BETWEEN 0-100", bg="#074463", borderwidth=10,
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold"), pady=2).place(x=2,
                                                                                                                 y=6,
                                                                                                                 width=835)
        self.window.title = Label(self.window, text="Players Details", bg="#074463", borderwidth=10,
                                  relief=GROOVE, fg="white", font=("times new roman", 22, "bold"), pady=2).place(x=300,y=73)
    def heads_checks_about_player_frame(self):
        self.gme_lbl_frm=Frame(self.window,bg="white",borderwidth=25,
                                relief=GROOVE).place(x=30,y=130,width=800,height=450)
       

        self.table=Treeview(self.gme_lbl_frm,columns=('A','B','C','D','E'),selectmode='extended')

        self.table.heading('#0',text='S.No')
        self.table.column('#0',minwidth=75,width=75,stretch='No')


        self.table.heading('#1',text='P_ID')
        self.table.column('#1',minwidth=90,width=90,stretch='No')

        self.table.heading('#2',text='Name')
        self.table.column('#2',minwidth=170,width=170,stretch='No')

        self.table.heading('#3',text='Email')
        self.table.column('#3',minwidth=200,width=200,stretch='No')

        self.table.heading('#4',text='password')
        self.table.column('#4',minwidth=200,width=200,stretch='No')
        

        m=0
        for i in guess_database.player_detail():
            self.table.insert('',0,text=i[0],values=(i[1],i[2],i[3],i[4]))
        m+=1
        #Binding
        self.table.place(x=50,y=150,width=750,height=405)
        self.abt_prd_prv_button=Button(self.window, text='Back',width=10,height=1,border=10,borderwidth=8,font=('arial',18),
                                 background="#00E856",foreground='white',command=self.abt_prd_prev_page,activebackground="#1701A1").place(x=700,y=70,width=130)

        
    #FUNCTION FOR GOTO DASHBOARD PAGE FROM ABOUTN PRODUCT PAGE
    def abt_prd_prev_page(self):
        m=messagebox.askquestion("Alert","Do You Want To Exit")
        if m=='yes':
            self.window.destroy()
            dash_board=head_dashboard.Head_dashboard()
            dash_board.head_dashboard_main()
        

if __name__ == '__main__':
    abt_gme=Heads_checks_about_player()
    abt_gme.heads_checks_about_player_frame()
