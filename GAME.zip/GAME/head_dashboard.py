from tkinter import *
from tkinter import messagebox
import head_checks_players_details
import head_login
import Lets_play
import Guess_the_no
import head_checks_players_score


class Head_dashboard:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('850x600+250+20')
        self.window.title('THIS GAME IS DEVELOPED BY AMAN AND ABHISHEK HEAD WINDOW')
        self.window.configure(background="blue")

        #-----------------ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY--------------------
        self.background_img_lft = PhotoImage(file="Images/img_guess.png")
        self.img_left = Label(self.window, image=self.background_img_lft).place(x=0, y=0)

    def head_dashboard_main(self):

        self.mainmenu = Menu(self.window)
        self.window.config(menu=self.mainmenu)

        '''self.pn = Menu(self.mainmenu)
        self.mainmenu.add_cascade(label="PLAY NOW", menu=self.pn)
        self.pn.add_command(label="Lets Play",command= self.play_now)'''


        self.gr = Menu(self.mainmenu)
        self.mainmenu.add_cascade(label="PLAYERS DETAIL", menu=self.gr)
        self.gr.add_command(label="Details",command= self.see_players_dtl)
        #self.gr.add_command(label="Add Grocery",command= self.goto_add_grocery_product_page)


        self.vw=Menu(self.mainmenu)
        self.mainmenu.add_cascade(label='PLAYERS SCORE',menu=self.vw)
        self.vw.add_command(label='Check Score', command=self.players_score)
        #self.vw.add_command(label='About Product', command=self.goto_about_product_page)
        
        self.lg=Menu(self.mainmenu)
        self.mainmenu.add_cascade(label='LOGOUT',menu=self.lg)
        self.lg.add_command(label='Logout', command=self.logout)

    #FUNCTION FOR  PLAYER CHECKING PLAYERS DETAIL
    def see_players_dtl(self):
        ask=messagebox.askquestion("Alert","Do You Want To Check Players Detail")
        if ask=='yes':
            self.window.destroy()
            abt_gme=head_checks_players_details.Heads_checks_about_player()
            abt_gme.heads_checks_about_player_frame()
        
    #FUNCTION FOR CHECKING PLAYERS SCORE
    def players_score(self):
        ask=messagebox.askquestion("Alert","Do You Want To See Score")
        if ask=='yes':
            self.window.destroy()
            score=head_checks_players_score.Head_checksPlayers_score()
            score.Head_checksPlayers_score_frame()

            

    #FUNCTION FOR LOGOUT  
    def logout(self):
        m=messagebox.askquestion("Exit","Do You Want To Logout")
        if m=='yes':
            self.window.destroy()
            log=head_login.Head_login()
            log.head_login_main()
            log.window.mainloop()

        

    

if __name__ == '__main__':
    dash_board=Head_dashboard()
    dash_board.head_dashboard_main()



