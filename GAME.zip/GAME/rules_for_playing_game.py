from tkinter import *
from tkinter import messagebox
import game_dashboard
class Rules:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('850x580+50+50')

        

        #-----------------ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY--------------------
        
        
        self.background_img_lft=PhotoImage(file="Images/Rules.png")
        self.img_left=Label(self.window,image=self.background_img_lft).place(x=0,y=0)

        
        self.window.title=Label(self.window,text="GUESS THE NUMBER BETWEEN 00-100",bg="#074463",borderwidth=10,
                                        relief=GROOVE,fg="white",font=("times new roman",22,"bold"),pady=2).place(x=4,y=3,width=810)

        '''self.window.title=Label(self.window,text="Click On Button To Play Again",bg="blue",borderwidth=3,
                                        relief=GROOVE,fg="white",font=("times new roman",15,"bold"),pady=1).place(x=3,y=300,width=350)'''
        self.abt_prd_prv_button=Button(self.window, text='Back',width=10,height=1,border=10,borderwidth=8,font=('arial',18),
                                 background="#00E856",foreground='white',command=self.abt_prd_prev_page,activebackground="#1701A1").place(x=660,y=70,width=130)

    #FUNCTION FOR GOTO DASHBOARD PAGE FROM ABOUTN PRODUCT PAGE
    def abt_prd_prev_page(self):
        m=messagebox.askquestion("Alert","Go To Profile Window")
        if m=='yes':
            self.window.destroy()
            dash_board=game_dashboard.Game_dashboard()
            dash_board.game_dashboard_main()

                    

if __name__ == '__main__':
    rule=Rules()
    

    
    
