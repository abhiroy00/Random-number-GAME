a=1220
b=20
c=10
d=40
e=50
f=120
g=70
h=80
i=901
if a!=b and a!=c and a!=d and a!=e and a!=f  and a!=g and a!=h and a!=i and b!=c and b!=d and b!=e and b!=f and b!=g and b!=h and b!=i and c!=d and c!=e and c!=f  and c!=g and c!=h and c!=i and d!=e and d!=f and d!=g and d!=h and d!=i and e!=f and e!=g and e!=h and e!=i and  f!=g and f!=h and f!=i and h!=i:          
    print(a)
    print(b)
    print(c)
    print(d)
    print(e)
    print(f)
    print(g)
    print(h)
    print(i)

else:
    print("uhhu")
