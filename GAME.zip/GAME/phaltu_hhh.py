import datetime
def hii():
    print(self.id_a.get())
    print(self.nme_b.get())
    print(self.eml_c.get())
    #self.pwd_c.get()
    self.score=100
    self.selected_no=self.Number2_won
    self.right_no=self.Number2_won
    print(self.selected_no)#selected No
    print(self.right_no)  # rightNo
    #==============date time=====================
    now= datetime.datetime.now()
    current_date=now.strftime("%d-%m-%Y")
    current_time=now.strftime('%X')
    print(current_date)
    print(current_time)
    #=============date time=====================
    add_dta=(self.id_a.get(),self.nme_b.get(),self.eml_c.get(),self.score,self.selected_no,self.right_no,current_date,current_time)
    m = guess_database.add_score(add_dta)  # This statement add score with the player name
    print("hiuh")
    print(m)
    print("hiuh")
    # ==============creating table dynamically===================
    ll=guess_database.filling_dta_to_dynamic_table(add_dta)# This statement add score with the player name does not show the anothe [player detail]
    print("hello")
    print(ll)
