from tkinter import *
#import mysql.connector
import random
from tkinter import messagebox
import guess_database
import wow_you_won
import game_dashboard
import Btn_1
import Btn_3
import Btn_4
import Btn_5
import Btn_6
import Btn_7
import Btn_8
import Btn_9
import bolo
import datetime

class Main_Window:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('850x600+250+20')

        self.background_img_lft=PhotoImage(file="Images/number_img.png")
        self.img_left=Label(self.window,image=self.background_img_lft).place(x=0,y=0,height=655)

        self.window.title=Label(self.window,text="GUESS THE NUMBER BETWEEN 00-100",bg="#074463",borderwidth=10,
                                        relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=2,y=6,width=835)

        self.chance_lft= Label(self.window, text="3 Chances Left", bg="white",activebackground="#1701A1" ,
                                          relief=GROOVE, fg="Red", font=("times new roman", 25, "bold")).place(x=250, y=90,width=300)

        self.Number1=random.randrange(1,100)
        self.Number2_won=random.randrange(1,100)
        self.Number3=random.randrange(1,100)
        self.Number4=random.randrange(1,100)
        self.Number5=random.randrange(1,100)
        self.Number6=random.randrange(1,100)
        self.Number7=random.randrange(1,100)
        self.Number8=random.randrange(1,100)
        self.Number9=random.randrange(1,100)
        
        print("MAINWINDOW")
        print(self.Number1)
        print(self.Number2_won)
        print(self.Number3)
        print(self.Number4)
        print(self.Number5)
        print(self.Number6)
        print(self.Number7)
        print(self.Number8)
        print(self.Number9)
        print("MAINWINDOW")

        self.no_of_guess=1
        self.max_guess=3

        if self.Number1 != self.Number2_won and self.Number1 != self.Number3 and self.Number1 != self.Number4 and self.Number1 != self.Number5 and self.Number1 != self.Number6 and self.Number1 != self.Number7 and self.Number1 != self.Number8 and self.Number1 != self.Number9 and self.Number2_won != self.Number3 and self.Number2_won != self.Number4 and self.Number2_won != self.Number5 and self.Number2_won != self.Number6 and self.Number2_won != self.Number7 and self.Number2_won != self.Number8 and self.Number2_won != self.Number9 and self.Number3 != self.Number4 and self.Number3 != self.Number5 and self.Number3 != self.Number6 and self.Number3 != self.Number7 and self.Number3 != self.Number8 and self.Number3 != self.Number9 and self.Number4 != self.Number5 and self.Number4 != self.Number6 and self.Number4 != self.Number7 and self.Number4 != self.Number8 and self.Number4 != self.Number9 and self.Number5 != self.Number6 and self.Number5 != self.Number7 and self.Number5 != self.Number8 and self.Number5 != self.Number9 and self.Number6 != self.Number7 and self.Number6 != self.Number8 and self.Number6 != self.Number9 and self.Number7 != self.Number8 and self.Number7 != self.Number9 and self.Number8 != self.Number9:
            
        
            self.first_btn = Button(self.window, text=self.Number1, width=5, bg="brown",command=lambda:self.you_loose_btn_1(),
                                           bd=12,activebackground="red", relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150,y=150)

            
            self.second_btn= Button(self.window, text=self.Number2_won,width=5, bg="#9272F4",activebackground="red" ,bd=12,command=lambda:self.you_won(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=350, y=150)

            
            self.third_btn= Button(self.window, text=self.Number3,width=5, bg="green",activebackground="red" ,bd=12,command=lambda:self.you_loose_btn_3(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=550, y=150)

            self.fourth_btn= Button(self.window, text=self.Number4,width=5, bg="green",activebackground="red" ,bd=12,command=lambda:self.you_loose_btn_4(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150, y=270)

            self.fifth_btn= Button(self.window, text=self.Number5,width=5, bg="pink",activebackground="red" ,bd=12,command=lambda:self.you_loose_btn_5(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=350, y=270)

            self.sixth_btn= Button(self.window, text=self.Number6,width=5, bg="brown",activebackground="red" ,bd=12,command=lambda:self.you_loose_btn_6(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=550, y=270)

            self.seventh_btn= Button(self.window, text=self.Number7,width=5, bg="brown",activebackground="red" ,bd=12,command=lambda:self.you_loose_btn_7(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150, y=390)

            self.eighth_btn= Button(self.window, text=self.Number8,width=5, bg="purple",activebackground="red" ,bd=12,command=lambda:self.you_loose_btn_8(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=350, y=390)

            self.ninth_btn= Button(self.window, text=self.Number9,width=5, bg="green",activebackground="red" ,bd=12,command=lambda:self.you_loose_btn_9(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=550, y=390)

            # WORKING WIYH DATABASE FOR GETTING NAME AND PASSWORD

            self.dtl_lbl_frm=Frame(self.window,bg="pink",borderwidth=20,
                                relief=GROOVE).place(x=18,y=498,width=820,height=95)#y=270--y=390
       

            k = guess_database.get_every_time_save_data()  # This statement tells you about the the player name
            print(k)
            for i in k:
                print(i)
            for n in i:
                print(n)
            self.p = i[1]# Id
            self.q=i[2]#name
            self.r=i[3]#email
            self.s=i[4]#password
            print(self.p)
            print(self.q)
            print(self.r)
            self.id_a=StringVar()
            self.nme_b=StringVar()
            self.eml_c=StringVar()
            
            self.id_a.set(self.p)
            self.nme_b.set(self.q)
            self.eml_c.set(self.r)


            #NAME WIDGET
            self.usr_id=Label(self.dtl_lbl_frm, text="Usr_Id",font=('arial',18),bg="pink",fg='black')
            self.usr_id.place(x=40,y=530)

            #FIELD OF USERNAME WIDGET
            self.usr_id_ent_field=Entry(self.dtl_lbl_frm,borderwidth=5,textvariable=self.id_a,state=DISABLED,font=('arial',16,'bold'),
                                          bg="pink",fg='black').place(x=140,y=529,width=100)

            
            #USER NAME WIDGET
            self.usr_name=Label(self.dtl_lbl_frm, text="Name",font=('arial',18),bg="pink",fg='black')
            self.usr_name.place(x=260,y=530)

            #ENTERY FIELD OF USERNAME WIDGET
            self.usr_name_ent_field=Entry(self.dtl_lbl_frm,borderwidth=5,textvariable=self.nme_b,state=DISABLED,font=('arial',16,'bold'),
                                          bg="pink",fg='black').place(x=345,y=529,width=180)

            #PASSWORD WIDGET
            self.eml=Label(self.dtl_lbl_frm, text='Email',width=8,font=('arial',18),
                               bg="pink",fg='black').place(x=525,y=530)

            #ENTERY FIELD OF PASSWORD WIDGET
            self.eml_ent_field=Entry(self.dtl_lbl_frm,borderwidth=5,textvariable=self.eml_c,state=DISABLED,font=('arial',16,'bold'),
                                         bg="pink",fg='black').place(x=645,y=529,width=170)
            

            '''#NAME WIDGET
            self.usr_id=Label(self.dtl_lbl_frm, text="Usr_Id",font=('arial',18),bg="pink",fg='black')
            self.usr_id.place(x=65,y=530)

            #FIELD OF USERNAME WIDGET
            self.usr_id_ent_field=Entry(self.dtl_lbl_frm,borderwidth=5,textvariable=self.id_a,state=DISABLED,font=('arial',16,'bold'),
                                          bg="pink",fg='black').place(x=155,y=529,width=100)

            #NAME WIDGET
            self.usr_name=Label(self.dtl_lbl_frm, text="Name",font=('arial',18),bg="pink",fg='black')
            self.usr_name.place(x=285,y=530)

            #FIELD OF USERNAME WIDGET
            self.usr_name_ent_field=Entry(self.dtl_lbl_frm,borderwidth=5,textvariable=self.nme_b,state=DISABLED,font=('arial',16,'bold'),
                                          bg="pink",fg='black').place(x=370,y=529,width=180)


            #USER NAME WIDGET
            self.eml=Label(self.dtl_lbl_frm, text="Email",font=('arial',18),bg="pink",fg='black')
            self.eml.place(x=500,y=530)

            #ENTERY FIELD OF USERNAME WIDGET
            self.eml_ent_field=Entry(self.dtl_lbl_frm,borderwidth=5,textvariable=self.eml_c,state=DISABLED,font=('arial',16,'bold'),
                                          bg="pink",fg='black').place(x=580,y=529,width=190)'''



        else:
            print("Two Or More Numbers Are Same In This Game!!!")
            self.n = messagebox.showinfo("Ooops", "Two Or More Numbers Are Same In This Game!")
            self.window.destroy()
            dash_board = game_dashboard.Game_dashboard()
            dash_board.game_dashboard_main()


    def you_won(self):
        if self.Number2_won:
            bolo.say(f"You Clicked On {self.Number2_won}")
            print()
            self.submit=messagebox.askquestion("Exit","Submit")
            if self.submit=='yes':
                bolo.say("Congratulation you won The game")
                r=messagebox.showinfo("Score","You Scored 100")
                self.window.destroy()
                dash_board=game_dashboard.Game_dashboard()
                dash_board.game_dashboard_main()
                #self.m=messagebox.showinfo("Great","Congratulation!!! you won!")
                print(self.id_a.get())
                print(self.nme_b.get())
                print(self.eml_c.get())
                #self.pwd_c.get()
                self.score=100
                self.selected_no=self.Number2_won
                self.right_no=self.Number2_won
                print(self.selected_no)#selected No
                print(self.right_no)  # rightNo
                #==============date time=====================
                now= datetime.datetime.now()
                current_date=now.strftime("%d-%m-%Y")
                current_time=now.strftime('%X')
                print(current_date)
                print(current_time)
                #==============date time=====================
                add_dta=(self.id_a.get(),self.nme_b.get(),self.eml_c.get(),self.score,self.selected_no,self.right_no,current_date,current_time)
                m = guess_database.add_score(add_dta)  # This statement add score with the player name
                print("hiuh")
                print(m)
                print("hiuh")
                # ==============creating table dynamically===================
                ll=guess_database.filling_dta_to_dynamic_table(add_dta)# This statement add score with the player name does not show the anothe [player detail]
                print("hello")
                print(ll)
                

                
                        # ==============creating table dynamically===================
                '''k = guess_database.get_every_time_save_data()  # This statement tells you about the the player name
                print(k)
                for i in k:
                    print(i)
                for n in i:
                    print(n)
                print("amamnamk")
                z = i[1]
                print(z)
                print("amamnamk")
                plr_id = z
                print(plr_id)
                # ==============creating table dynamically===================
                try:
                    # -------CONNECTION CREATED----------------------------------------------
                    conn = mysql.connector.connect(user='root', password='', host='localhost', database='guess_no', port=3306)
                    if (conn.is_connected()):
                        print("Successfully...Connected!!!!")

                except:
                    print("UNABLE TO CONNECT")
                print("jhbjh")
                print(plr_id)
                # ---------CREATING TABLE,---DYNAMICALLY------------
                sql = f"INSERT INTO {plr_id}(name,email,score,selected_no,right_no,date,time) values (%s,%s,%s,%s,%s,%s,%s)"
                print("hgvgh")
                myc = conn.cursor()
                try:
                    print("jjh")
                    myc.execute(sql, add_dta)
                    conn.commit()
                    return True
                    print("Successfully...Table Created!!!")
                except:
                    print("Unable To Create Table!!!")'''
                # ===============================================================================================

    def you_loose_btn_1(self):
        #if self.Number1 or self.Number3 or self.Number4 or self.Number5 or self.Number6 or self.Number7 or self.Number8 or self.Number9:
        if self.Number1:
            bolo.say(f"You Clicked On {self.Number1}")
            print()
            self.select=messagebox.askquestion("Exit","Submit")
            if self.select=='yes':
                bolo.say("You are so close to win ")
                self.n=messagebox.showinfo("Ooops","Better Luck!!! Play Next Chance!")
                #self.mi=messagebox.askquestion("Exit","Choose Again!!!!")
                print("OOPS!!! you LOOSE!","Chances Left:",self.no_of_guess)
                if self.n=='ok':
                    self.window.destroy()
                    btn_1_window=Btn_1.Btn_1_Window()

                
            

    def you_loose_btn_3(self):
        if self.Number3:
            bolo.say(f"You Clicked On {self.Number3}")
            print()
            self.select=messagebox.askquestion("Exit","Submit")
            if self.select=='yes':
                bolo.say("You are too close to win ")
                self.n=messagebox.showinfo("Ooops","Better Luck!!! Play Next Chance!")
                #self.mi=messagebox.askquestion("Exit","Choose Again!!!!")
                print("OOPS!!! you LOOSE!","Chances Left:",self.no_of_guess)
                if self.n=='ok':
                    self.window.destroy()
                    btn_3_window=Btn_3.Btn_3_Window()


    def you_loose_btn_4(self):
        if self.Number4:
            bolo.say(f"You Clicked On {self.Number4}")
            print()
            self.select=messagebox.askquestion("Exit","Submit")
            if self.select=='yes':
                bolo.say("You are too close to win ")
                self.n=messagebox.showinfo("Ooops","Better Luck!!! Play Next Chance!")
                #self.mi=messagebox.askquestion("Exit","Choose Again!!!!")
                print("OOPS!!! you LOOSE!","Chances Left:",self.no_of_guess)
                if self.n=='ok':
                    self.window.destroy()
                    btn_4_window=Btn_4.Btn_4_Window()


    def you_loose_btn_5(self):
        if self.Number5:
            bolo.say(f"You Clicked On {self.Number5}")
            print()
            self.select=messagebox.askquestion("Exit","Submit")
            if self.select=='yes':
                bolo.say("You are too close to win ")
                self.n=messagebox.showinfo("Ooops","Better Luck!!! Play Next Chance!")
                #self.mi=messagebox.askquestion("Exit","Choose Again!!!!")
                print("OOPS!!! you LOOSE!","Chances Left:",self.no_of_guess)
                if self.n=='ok':
                    self.window.destroy()
                    btn_5_window=Btn_5.Btn_5_Window()

    def you_loose_btn_6(self):
        if self.Number6:
            bolo.say(f"You Clicked On {self.Number6}")
            print()
            self.select=messagebox.askquestion("Exit","Submit")
            if self.select=='yes':
                bolo.say("You are too close to win ")
                self.n=messagebox.showinfo("Ooops","Better Luck!!! Play Next Chance!")
                #self.mi=messagebox.askquestion("Exit","Choose Again!!!!")
                print("OOPS!!! you LOOSE!","Chances Left:",self.no_of_guess)
                if self.n=='ok':
                    self.window.destroy()
                    btn_6_window=Btn_6.Btn_6_Window()

    def you_loose_btn_7(self):
        if self.Number7:
            bolo.say(f"You Clicked On {self.Number7}")
            print()
            self.select=messagebox.askquestion("Exit","Submit")
            if self.select=='yes':
                bolo.say("You are too close to win ")
                self.n=messagebox.showinfo("Ooops","Better Luck!!! Play Next Chance!")
                #self.mi=messagebox.askquestion("Exit","Choose Again!!!!")
                print("OOPS!!! you LOOSE!","Chances Left:",self.no_of_guess)
                if self.n=='ok':
                    self.window.destroy()
                    btn_7_window=Btn_7.Btn_7_Window()


    def you_loose_btn_8(self):
        if self.Number8:
            bolo.say(f"You Clicked On {self.Number8}")
            print()
            self.select=messagebox.askquestion("Exit","Submit")
            if self.select=='yes':
                bolo.say("You are too close to win ")
                self.n=messagebox.showinfo("Ooops","Better Luck!!! Play Next Chance!")
                #self.mi=messagebox.askquestion("Exit","Choose Again!!!!")
                print("OOPS!!! you LOOSE!","Chances Left:",self.no_of_guess)
                if self.n=='ok':
                    self.window.destroy()
                    btn_8_window=Btn_8.Btn_8_Window()

    def you_loose_btn_9(self):
        if self.Number9:
            bolo.say(f"You Clicked On {self.Number9}")
            print()
            self.select=messagebox.askquestion("Exit","Submit")
            if self.select=='yes':
                bolo.say("You are too close to win ")
                self.n=messagebox.showinfo("Ooops","Better Luck!!! Play Next Chance!")
                #self.mi=messagebox.askquestion("Exit","Choose Again!!!!")
                print("OOPS!!! you LOOSE!","Chances Left:",self.no_of_guess)
                if self.n=='ok':
                    self.window.destroy()
                    btn_9_window=Btn_9.Btn_9_Window()

    def save_no(self):
        k=guess_database.insert_rand_no(self.Number1,self.Number2_won,self.Number3,self.Number4,self.Number5,self.Number6,self.Number7,self.Number8,self.Number9)
        if k == True:
            print('Number is inserted')
        elif k== False:
            print('Number is not inserted')
                


            
            
                    

if __name__ == '__main__':
    dash_board=Main_Window()
    dash_board.save_no()

    
    
