import login_page
import guess_database

s=login_page.Login

#s.reg_main()

p_id=guess_database.fetch_plr_id()
print(p_id)
print(p_id[1])
