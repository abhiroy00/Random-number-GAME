import guess_database
#Fetching Random no from database
print("dhufjahdhh")
m=guess_database.register()#import guess_database
print(m)
for i in m:
    print(i)
for k in i:
    print(k)
        
