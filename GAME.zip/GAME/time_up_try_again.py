from tkinter import *
from tkinter import messagebox
import Guess_the_no

class Wow__you_won:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('400x266+250+50')

        

        #-----------------ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY--------------------
        
        self.background_img_lft=PhotoImage(file="Images/time_up_try_again.png")
        self.img_left=Label(self.window,image=self.background_img_lft).place(x=0,y=0)

        
        self.window.title=Label(self.window,text="GUESS THE NUMBER BETWEEN 00-100",bg="#074463",borderwidth=10,
                                        relief=GROOVE,fg="white",font=("times new roman",10,"bold"),pady=2).place(x=4,y=3,width=400)

        '''self.window.title=Label(self.window,text="Click On Button To Play Again",bg="blue",borderwidth=3,
                                        relief=GROOVE,fg="white",font=("times new roman",15,"bold"),pady=1).place(x=3,y=300,width=350)'''

        

        

    def coundown(self):
        #self.i=time()
        #self.i=30
        self.timer_btn= Button(self.window, text=" Play Again",width=5,height=1, bg="red",activebackground="red" ,bd=4,command=lambda:self.play_again(),
                                          relief=GROOVE, fg="white", font=("times new roman", 15, "bold")).place(x=140,y=210,width=120)
        
        
    def play_again(self):
        self.mi = messagebox.askquestion("Alert", "Wants To Play Again!!!!")
        if self.mi =='yes':
            self.window.destroy()
            dash_board=Guess_the_no.Main_Window()
            dash_board.save_no()
        else:
            pass
        

            


                    

if __name__ == '__main__':
    you_won=Wow__you_won()
    you_won.coundown()
    you_won.window.mainloop()
    

    
    
