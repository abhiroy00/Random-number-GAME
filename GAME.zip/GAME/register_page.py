from tkinter import *
#import dashboard_page
import guess_database
import login_page
from tkinter import messagebox
import mysql.connector

class Register:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('1000x550+100+30')
        self.window.title('BILLING SOFTWARE DEVELOPED BY AMAN KUMAR')
        self.window.configure(background="blue")

        #ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY
        
        self.background_img_lft=PhotoImage(file="Images/question_img.png")
        self.img_left=Label(self.window,
                           image=self.background_img_lft).place(x=0,y=0)

        #--------------HEADIN--GUESS THE NUMBER----------------
        
        self.window.title=Label(self.window,text="GUESS THE NUMBER BETWEEN 00-100",bg="#074463",borderwidth=10,
                                        relief=GROOVE,fg="white",font=("times new roman",28,"bold"),pady=2).place(x=2,y=6,width=1000)
    
        #------------------HEADING--SHOP NAME----------------
        self.window.title=Label(self.window,text="Try Your Luck",bg="#074463",borderwidth=8,
                                relief=GROOVE,fg="white",font=("times new roman",20,"bold"),pady=2).place(x=0,y=70,width=1000)
        #REGISTER HERE INFORMED
        self.window.title=Label(self.window,text="REGISTER HERE....",bg="#1701A1",borderwidth=5,
                                relief=GROOVE,fg="white",font=("times new roman",22,"bold"),pady=2).place(x=150,y=125,width=300)
        
        #FUNCTION CREATED FOR WIDGETS
    def reg_main(self):
        #textvariable
        self.p_id = StringVar()
        self.reg_a=StringVar()
        self.reg_b=StringVar()
        self.reg_c=StringVar()

        # PLAYER ID WIDGET
        self.pid = Label(self.window, text="Player Id", font=('arial', 24, 'bold'),
                          bg="#7B004E", fg='white').place(x=370, y=182)

        # ENTERY FIELD OF PLAYER ID
        self.pid_ent_field = Entry(self.window, borderwidth=10, textvariable=self.p_id, font=('arial', 24, 'bold'),
                                    bg="white", fg='black').place(x=570, y=175, width=270)

        #USER NAME WIDGET
        self.name=Label(self.window, text="Your Name",font=('arial',24,'bold'),
                                bg="#7B004E",fg='white').place(x=370,y=250)

        #ENTERY FIELD OF NAME WIDGET
        self.name_ent_field=Entry(self.window,borderwidth=10,textvariable=self.reg_a,font=('arial',24,'bold'),
                                      bg="white",fg='black').place(x=570,y=245,width=270)

        #USER PHONE MOBILE
        self.phone=Label(self.window, text="Email",font=('arial',24,'bold'),
                                bg="#7B004E",fg='white').place(x=370,y=320)

        #ENTERY PHONE MOBILE WIDGET
        self.phone_ent_field=Entry(self.window,borderwidth=10,textvariable=self.reg_b,font=('arial',24,'bold'),
                                      bg="white",fg='black').place(x=570,y=310,width=270)

        #EMAIL WIDGET
        self.email_emp_pwd=Label(self.window, text='Password',width=8,font=('arial',24,'bold'),
                           bg="#7B004E",fg='white').place(x=370,y=390)

        #ENTERY FIELD OF EMAIL WIDGET
        self.email_emp_pwd_ent_field=Entry(self.window,borderwidth=10,textvariable=self.reg_c,font=('arial',24,'bold'),
                                     bg="white",fg='black').place(x=570,y=380,width=270)

        #REGISTER BUTTON WIDGET
        self.reg_button=Button(self.window, text='Register',width=10,height=1,border=10,command=self.register_yr_slf,borderwidth=8,font=('arial',18),
                                 background="#CC012B",foreground='white',activebackground="#1701A1").place(x=530,y=465)
                
        
    #FUNCTION FOR GO TO LOGIN PAGE
    def goto_login_page(self):
        m=messagebox.askquestion("Exit","Do You Want To Go To Login Window")
        if m=='yes':
            self.window.destroy()
            calling_login_page=login_page.Login()
            calling_login_page.main()

    def register_yr_slf(self):
        #-----------SHOWS MESSAGE FOR INSERTED SUCCESSFULLY------------
        h=self.p_id.get()
        hh="p_id"+h
        i=self.reg_a.get()
        j=self.reg_b.get()
        k=self.reg_c.get()
        
        if self.p_id.get()=="" or self.reg_a.get()=="" or  self.reg_b.get()=="" or self.reg_c.get()=="":
            messagebox.showwarning("Warning","Empty Box")
        else:
            u=guess_database.register(hh,i,j,k)
            print(u)
            if u == True:
                #==============creating table dynamically===================
                p=guess_database.dynamic_table()
                #==============creating table dynamically===================
                '''try:
                #-------CONNECTION CREATED----------------------------------------------
                    conn=mysql.connector.connect(user='root',password='',host='localhost',database='guess_no',port=3306)
                    if(conn.is_connected()):
                        print("Successfully...Connected!!!!")
                                
                except:
                    print("UNABLE TO CONNECT")
                print("jhbjh")
                plr_id=hh
                print(plr_id)
                print("heel")
                #---------CREATING TABLE,---DYNAMICALLY------------
                sql=f"CREATE TABLE {plr_id}(id INT PRIMARY KEY AUTO_INCREMENT,name VARCHAR(255),email VARCHAR(255),score VARCHAR(255),selected_no VARCHAR(255),right_no VARCHAR(255),date VARCHAR(255),time VARCHAR(255))"
                print("hgvgh")
                myc=conn.cursor()
                try:
                    print("jjh")
                    myc.execute(sql)
                    print("Successfully...Table Created!!!")
                except:
                    print("Unable To Create Table!!!")'''
                #===============================================================================================

                print('Successfully Registered')
                messagebox.showwarning("Success"," Registered Successfully")
                self.window.destroy()
                calling_login_page=login_page.Login()
                calling_login_page.main()
            elif u == False:
                print('Not Registered')
                messagebox.showwarning("Warning","Not Registered")
        
if __name__ == '__main__':
    reg=Register()
    reg.reg_main()

