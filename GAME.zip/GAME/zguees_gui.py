from tkinter import *
import random
from tkinter import messagebox

print("GUESS NO. BETWEEN 0-100")
no_of_guess=1
max_guess=10
''''while no_of_guess<=max_guess:
    p=int(input("Enter Number To Guess Number:-"))
    if p<20:
        print("Enter Larger Number Than:-",p)
        print()
        print("No Of Chances Left ",max_guess-no_of_guess)
        if max_guess-no_of_guess==0:
            print("Game Over!!! You Lose!! Try Next Time")
    elif p>20:
        print("Enter Smaller Number Than",p)
        print()
        print("No Of Chances Left ",max_guess-no_of_guess)
        if max_guess-no_of_guess==0:
            print("Game Over!!! You Lose!! Try Next Time")
    elif p==20:
        print()
        print("Congratulation!!! you won!","You Took:",no_of_guess)
        break
    no_of_guess+=1'''


Number=random.randrange(1,100)
Number2=random.randrange(1,100)
Number3=random.randrange(1,100)
Number4=random.randrange(1,100)
print(Number)
print(Number2)
print(Number3)
print(Number4)

window=Tk()
window.geometry('1150x680+10+30')

window.title=Label(window,text="GUESS THE NUMBER BETWEEN 0-100",bg="#074463",borderwidth=10,
                                relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=0,y=6,width=1145)


        
first_btn = Button(window, text=Number, width=5, bg="#9272F4",command=lambda:number_1(),
                                   bd=12,activebackground="#1701A1", relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150, y=150)
        
        
        
second_btn = Button(window, text=Number2, width=5, bg="#9272F4", bd=12,command=lambda:btn_2(),
                                   activebackground="#1701A1",relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=420, y=150)
        
third_btn= Button(window, text=Number3,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:btn_3(),
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=650, y=150)

fourth_btn= Button(window, text=Number4,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:btn_4(),
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=870, y=150)

fifth_btn= Button(window, text=Number3,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:btn_3(),
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=450, y=350)

sixth_btn= Button(window, text=Number4,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:btn_4(),
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=670, y=350)

def number_1():
    if Number:
        print()
        min=messagebox.askquestion("Exit","Submit")
        if min=='yes':
            n=messagebox.askquestion("Exit","Congratulation!!! you won!")
            print("Congratulation!!! you won!","You Took:",no_of_guess)


#-----------------------------------------------------WORKING ON BUTTON SECOND---------------------------------------------

def btn_2_removed():
    window=Tk()
    window.geometry('1150x680+10+30')

    window.title=Label(window,text="GUESS THE NUMBER BETWEEN 0-100",bg="#074463",borderwidth=10,
                                    relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=0,y=66,width=1345)




    third_btn= Button(window, text=Number3,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:btn_3(),
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150, y=150)

    first_btn = Button(window, text=Number, width=5, bg="#9272F4",command=lambda:number_1(),
                                   bd=12,activebackground="#1701A1", relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=420, y=150)

    fourth_btn= Button(window, text=Number4,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:btn_4(),
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=650, y=150)

    fifth_btn= Button(window, text=Number3,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:btn_3(),
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=450, y=350)

    sixth_btn= Button(window, text=Number4,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:btn_4(),
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=670, y=350)


    
def btn_2():
    if Number:
        print()
        min=messagebox.askquestion("Exit","Submit")
        if min=='yes':
            n=messagebox.askquestion("Exit","Wrong!!! you Loose!")
            mi=messagebox.askquestion("Exit","Choose Again!!!!")
            print("OOPS!!! you LOOSE!","You Took:",no_of_guess)
            if mi=='yes':
                window.destroy()
                btn_2_removed()




                    

