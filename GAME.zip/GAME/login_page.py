from tkinter import *
from tkinter import messagebox
import register_page
import guess_database
import game_dashboard
import bolo



class Login:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('1000x520+110+40')
        self.window.title('GUESS THE NUMBER DEVELOPED BY AMAN KUMAR')
        self.window.configure(background="blue")


        #ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY
        
        self.background_img=PhotoImage(file="Images/question_img.png")
        self.img_leftt=Label(self.window,
                           image=self.background_img).place(x=0,y=0)

        self.background_img_lft=PhotoImage(file="Images/user_login.png")#user_login
        self.img_left=Label(self.window,
                           image=self.background_img_lft).place(x=500,y=90)

        #--------------HEADIN--GUESS THE NUMBER----------------
        
        self.window.title=Label(self.window,text="GUESS THE NUMBER BETWEEN 00-100",bg="#074463",borderwidth=10,
                                        relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=2,y=6,width=1000)
    
        #------------------HEADING--SHOP NAME----------------
        '''self.window.title=Label(self.window,text="Try Your Luck",bg="#074463",borderwidth=10,
                                relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=0,y=75,width=1000)'''

        
        
        #FUNCTION CREATED FOR WIDGETS
    def main(self):
        self.usr_a=StringVar()
        self.pwd_b=StringVar()

        
        #USER NAME WIDGET
        self.emp_name=Label(self.window, text="User Name",font=('arial',24,'bold'),bg="#7B004E",fg='white')
        self.emp_name.place(x=320,y=220)

        #ENTERY FIELD OF USERNAME WIDGET
        self.emp_name_ent_field=Entry(self.window,borderwidth=10,textvariable=self.usr_a,font=('arial',24,'bold'),
                                      bg="white",fg='black').place(x=520,y=215,width=400)

        #PASSWORD WIDGET
        self.emp_pwd=Label(self.window, text='Password',width=8,font=('arial',24,'bold'),
                           bg="#7B004E",fg='white').place(x=320,y=285)

        #ENTERY FIELD OF PASSWORD WIDGET
        self.emp_pwd_ent_field=Entry(self.window,borderwidth=10,textvariable=self.pwd_b,font=('arial',24,'bold'),
                                     bg="white",fg='black').place(x=520,y=280,width=400)

        #REGISTER BUTTON WIDGET
        self.reg_button=Button(self.window, text='Register Now...',width=10,height=1,command=self.goto_reg_page,border=10,borderwidth=6,font=('arial',8),
                                 background="#009700",foreground='white',activebackground="#1701A1").place(x=610,y=340,width=120)

        
        #LOGIN BUTTON WIDGET
        self.Login_button=Button(self.window, text='Login',width=10,height=1,command=self.srt_gme,border=10,borderwidth=8,font=('arial',18),
                                 background="#CC012B",foreground='white',activebackground="#1701A1").place(x=550,y=375)
        
    #FUNCTION FOR GO TO DASH BOARDPAGE
    def srt_gme(self):
        a=self.usr_a.get()
        b=self.pwd_b.get()
        logg=guess_database.login(a,b)
        print(logg)
        if self.usr_a.get()=="" or self.pwd_b.get()=="":
            messagebox.showinfo("Alert","Empty Boxes")
        else:


            if logg:
                messagebox.showinfo("Success","Successfully Login")
                m=guess_database.find_name(a,b)#This statement tells you about the the player name
                print(m)
                for i in m:
                    print(i)
                for j in i:
                    print(j)

                self.p=m[1]
                self.q=m[2]
                self.r=m[3]
                self.t = m[4]
                print('hello')
                print(self.p)
                print(self.q)
                print(self.r)
                print(self.t)
                print('hellll')
                k = guess_database.every_time_save_data(self.p, self.q, self.r,self.t)
                if k == True:
                    print('Data is inserted')
                elif k == False:
                    print('Data is not inserted')
                bolo.say(f"log in Successfully")
                self.window.destroy()
                dash_board=game_dashboard.Game_dashboard()
                dash_board.game_dashboard_main()

            else:
                messagebox.showinfo("Alert","Username and Password Not Matched")
#===================================================================================

            #Try Again Throught This Way
        '''elif c==self.usr_a.get() and c==self.pwd_b.get():
            messagebox.showinfo("Success","Successfully Login")
            self.window.destroy()
            calling_dashboard_module=dashboard_page.dashboard()
            calling_dashboard_module.dashboard_main()

        else:
            messagebox.showinfo("Alert","Username and Password Not Matched")
            print("user password not matched")'''

#=======================================================================================










        
#==================================================================================================
            #SIMPLE LOGIN 
        
        '''if self.emp_a.get()=="" or self.pwd_b.get()=="":
            messagebox.showinfo("Alert","Empty Boxes")

        elif self.emp_a.get()=='amansham12345@gmail.com' and self.pwd_b.get()=='indian':
            messagebox.showinfo("Success","Successfully Login")
            self.window.destroy()
            calling_dashboard_module=dashboard_page.dashboard()
            calling_dashboard_module.dashboard_main()
            
        else:
            messagebox.showinfo("Alert","Username and Password Not Matched")
            print("user password not matched")'''

#==================================================================================================            

            
            
        
            
        
    #FUNCTION FOR GO TO REGISTER PAGE
    def goto_reg_page(self):
        ask=messagebox.askquestion("Alert","Do You Want To Register")
        if ask=='yes':
            self.window.destroy()
            calling_reg_page=register_page.Register()
            calling_reg_page.reg_main()
        
if __name__ == '__main__':
    log=Login()
    log.main()
    log.window.mainloop()

