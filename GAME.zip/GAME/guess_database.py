import sys

import mysql.connector
con=mysql.connector.connect(
    host='localhost',
    user='root',
    password='Abhi7464@',
    database='guess_no')
cursor=con.cursor()
#======================================================================

def every_time_save_data(*tup):
    try:
        cursor.execute('INSERT INTO everytime_savedata (p_id,name,email,password) values (%s,%s,%s,%s)',tup)
        con.commit()
        return True
    except:
        return False

def get_every_time_save_data():
    try:
        sql='SELECT * FROM everytime_savedata'
        cursor.execute(sql)
        return cursor.fetchall()
        print("dfsf")
    except:
        return False
print("hihj")
#==================================================================


def player_detail():
    sql='SELECT * FROM register'
    cursor.execute(sql)
    return cursor.fetchall()

#ADD SCORE
def add_score(arg):
    try:
        sql='INSERT INTO players_score(p_id,name,email,score,selected_no,right_no,date,time) values (%s,%s,%s,%s,%s,%s,%s,%s)'
        cursor.execute(sql,arg)
        con.commit()
        return True
    except:
        return False

#Registeration
def register(*arg):
    try:
        sql='INSERT INTO register(p_id,name,email,password) VALUES(%s,%s,%s,%s)'
        cursor.execute(sql,arg)
        con.commit()
        return True
    except:
        return False

#Login
def login(*u_pd):
    try:
        sql='SELECT * FROM register WHERE email=%s and password=%s'
        cursor.execute(sql,u_pd)
        return cursor.fetchone()
    except:
        return False

#----------------------------------------------------------------------------------
#filling data in all columns in About Players----------------
def select_player_dtl():
    sql='SELECT * FROM players_score'
    cursor.execute(sql)
    return cursor.fetchall()

select_player_dtl()


#Find Name
def find_name(*u_pd):
    try:
        sql='SELECT * FROM register WHERE email=%s and password=%s'
        cursor.execute(sql,u_pd)
        return cursor.fetchone()
    except:
        return False


def insert_rand_no(*arg):
    try:
        cursor.execute('INSERT INTO rand_num (num_1,num_2,num_3,num_4,num_5,num_6,num_7,num_8,num_9) values (%s,%s,%s,%s,%s,%s,%s,%s,%s)',arg)
        con.commit()
        return True
    except:
        return False

print("hello")
def get_rand_no():
    try:
        sql='SELECT * FROM rand_num'
        cursor.execute(sql)
        return cursor.fetchall()
        print("dfsf")
    except:
        return False
print("hihj")

get_rand_no()

#================head register========================
#Registeration
def h_register(*arg):
    try:
        sql='INSERT INTO head_register(h_name,h_email,h_password) VALUES(%s,%s,%s)'
        cursor.execute(sql,arg)
        con.commit()
        return True
    except:
        return False

#Login
def head_login(*u_pd):
    try:
        sql='SELECT * FROM head_register WHERE h_email=%s and h_password=%s'
        cursor.execute(sql,u_pd)
        return cursor.fetchone()
    except:
        return False

#filling player score dynamically
def player_id_table():
    k = get_every_time_save_data()  # This statement tells you about the the player name
    print(k)
    for i in k:
        print(i)
    for n in i:
        print(n)
    print("amamnamk")
    z = i[1]
    print(z)
    print("amamnamk")
    plr_id = z
    print(plr_id)

    try:
        sql=f"SELECT * FROM {plr_id}"
        cursor.execute(sql)
        return cursor.fetchall()
    except:
        return False

#filling to spectific player by using player id

def filling_dta_to_dynamic_table(add_dta):
    # ==============illing_dta_to_dynamic table dynamically===================
    k = get_every_time_save_data()  # This statement tells you about the the player name
    print(k)
    for i in k:
        print(i)
    for n in i:
        print(n)
    print("amamnamk")
    z = i[1]
    print(z)
    print("amamnamk")
    plr_id = z
    print(plr_id)
    print("jhbjh")
    print(plr_id)
    # ---------CREATING TABLE,---DYNAMICALLY------------
    sql = f"INSERT INTO {plr_id}(p_id,name,email,score,selected_no,right_no,date,time) values (%s,%s,%s,%s,%s,%s,%s,%s)"
    print("hgvgh")
    myc = con.cursor()
    try:
        print("jjh")
        c=cursor.execute(sql, add_dta)
        con.commit()
        return True
        print("Successfully...Table Created!!!")
    except:
        print("Unable To Create Table!!!")


#creatinf tabhle dynamically for storing players score

def dynamic_table():
    k = player_detail()  # This statement tells you about the the player name
    print(k)
    for i in k:
        print(i)
    for n in i:
        print(n)
    print("amamnamk")
    z = i[1]
    print(z)
    print("amamnamk")
    plr_id = z
    print(plr_id)
    print("jhbjh")
    print(plr_id)
    print("heel")
    # ---------CREATING TABLE,---DYNAMICALLY------------
    sql = f"CREATE TABLE {plr_id}(id INT PRIMARY KEY AUTO_INCREMENT,p_id VARCHAR(255),name VARCHAR(255),email VARCHAR(255),score VARCHAR(255),selected_no VARCHAR(255),right_no VARCHAR(255),date VARCHAR(255),time VARCHAR(255))"
    print("hgvgh")
    try:
        print("jjh")
        cursor.execute(sql)
        print("Successfully...Table Created!!!")
    except:
        print("Unable To Create Table!!!")
    # ===============================================================================================
