from tkinter import *
import random
from tkinter import messagebox
import guess_database
import Guess_the_no
import bolo
import game_dashboard
import datetime
import right_answer
#import Btn_3
#import Btn_4
#import Btn_5
#import Btn_6
#import Btn_7
#import Btn_8
#import Btn_9

class Btn_6_5_8_Window:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('850x600+250+50')

        self.background_img_lft = PhotoImage(file="Images/img_guess.png")
        self.img_left = Label(self.window, image=self.background_img_lft).place(x=0, y=0)

        self.window.title = Label(self.window, text="GUESS THE NUMBER BETWEEN 0-100", bg="#074463", borderwidth=10,
                                  relief=GROOVE, fg="white", font=("times new roman", 30, "bold"), pady=2).place(x=2,
                                                                                                                 y=6,
                                                                                                                 width=835)

        self.chance_lft = Label(self.window, text="Select Right Number Otherwise You Loose!!!", bg="white",
                                activebackground="#1701A1",
                                relief=GROOVE, fg="Red", font=("times new roman", 25, "bold")).place(x=90, y=90)
        #Fetching Random no from database
        print("dhufjahdhh")
        '''m = [i[0] for i in guess_database.insert_rand_no()]
        print(m)'''
        m=guess_database.get_rand_no()
        print(m)
        for i in m:
            print(i)
        for k in i:
            print(k)
        #print(i[0])
        self.num1 = i[1]
        self.num2_won = i[2]
        self.num3 = i[3]
        self.num4 = i[4]
        self.num5 = i[5]
        self.num6 = i[6]
        self.num7 = i[7]
        self.num8 = i[8]
        self.num9 = i[9]

        print("BUtton==1")
        print("")

        #print(obj.num1)
        print(self.num2_won)
        print(self.num3)
        print(self.num4)
        print(self.num5)
        print(self.num6)
        print(self.num7)
        print(self.num8)
        print(self.num9)

        

        self.no_of_guess=1
        self.max_guess=3

        if  self.num2_won != self.num5 != self.num6 != self.num7 != self.num8 != self.num9: 

            self.first_btn = Button(self.window, text=self.num1, width=5, bg="#9272F4",command=lambda:self.time_up(),
                                           bd=12,activebackground="#1701A1", relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150,y=150)

            self.second_btn= Button(self.window, text=self.num2_won,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:self.you_won(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=350, y=150)

            
            self.third_btn= Button(self.window, text=self.num3,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:self.time_up(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=550, y=150)

            self.fourth_btn= Button(self.window, text=self.num4,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:self.time_up(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150, y=270)

            '''self.fifth_btn= Button(self.window, text=self.num5,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:self.time_up(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=350, y=270)

            self.sixth_btn= Button(self.window, text=self.num6,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:self.time_up(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=550, y=270)'''

            self.seventh_btn= Button(self.window, text=self.num7,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:self.time_up(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150, y=390)

            '''self.eighth_btn= Button(self.window, text=self.num8,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:self.time_up(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=350, y=390)'''

            self.ninth_btn= Button(self.window, text=self.num9,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,command=lambda:self.time_up(),
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=550, y=390)

            # WORKING WIYH DATABASE FOR GETTING NAME AND PASSWORD

            self.dtl_lbl_frm = Frame(self.window, bg="pink", borderwidth=20,
                                     relief=GROOVE).place(x=18, y=498, width=820, height=95)  # y=270--y=390

            k = guess_database.get_every_time_save_data()  # This statement tells you about the the player name
            print(k)
            for i in k:
                print(i)
            for n in i:
                print(n)
            self.p = i[1]  # Id
            self.q = i[2]  # name
            self.r = i[3]  # email
            self.s = i[4]  # password
            print(self.p)
            print(self.q)
            print(self.r)
            self.id_a = StringVar()
            self.nme_b = StringVar()
            self.eml_c = StringVar()

            self.id_a.set(self.p)
            self.nme_b.set(self.q)
            self.eml_c.set(self.r)

            # ID WIDGET
            self.usr_id = Label(self.dtl_lbl_frm, text="Usr_Id", font=('arial', 18), bg="pink", fg='black')
            self.usr_id.place(x=40, y=530)

            # FIELD OF ID WIDGET
            self.usr_id_ent_field = Entry(self.dtl_lbl_frm, borderwidth=5, textvariable=self.id_a, state=DISABLED,
                                          font=('arial', 16, 'bold'),
                                          bg="pink", fg='black').place(x=140, y=529, width=100)

            # USER NAME WIDGET
            self.usr_name = Label(self.dtl_lbl_frm, text="Name", font=('arial', 18), bg="pink", fg='black')
            self.usr_name.place(x=260, y=530)

            # ENTERY FIELD OF USERNAME WIDGET
            self.usr_name_ent_field = Entry(self.dtl_lbl_frm, borderwidth=5, textvariable=self.nme_b, state=DISABLED,
                                            font=('arial', 16, 'bold'),
                                            bg="pink", fg='black').place(x=345, y=529, width=180)

            # PASSWORD WIDGET
            self.eml = Label(self.dtl_lbl_frm, text='Email', width=8, font=('arial', 18),
                             bg="pink", fg='black').place(x=525, y=530)

            # ENTERY FIELD OF PASSWORD WIDGET
            self.eml_ent_field = Entry(self.dtl_lbl_frm, borderwidth=5, textvariable=self.eml_c, state=DISABLED,
                                       font=('arial', 16, 'bold'),
                                       bg="pink", fg='black').place(x=645, y=529, width=170)
            
        else:
            print("Two Or More Numbers Are Same In This Game!!!!")
            self.n = messagebox.showinfo("Ooops", "Two Or More Numbers Are Same In This Game!")
            self.window.destroy()
            dash_board = game_dashboard.Game_dashboard()
            dash_board.game_dashboard_main()

    def you_won(self):
        if self.num2_won:
            bolo.say(f"You Clicked On {self.num2_won}")
            print()
            self.submit = messagebox.askquestion("Exit", "Submit")
            if self.submit == 'yes':
                bolo.say("Congratulation you won The game")
                r = messagebox.showinfo("Score", "You Scored 10")
                self.window.destroy()
                dash_board = game_dashboard.Game_dashboard()
                dash_board.game_dashboard_main()
                # self.m=messagebox.showinfo("Great","Congratulation!!! you won!")
                print(self.id_a.get())
                print(self.nme_b.get())
                print(self.eml_c.get())
                # self.pwd_c.get()
                self.score = 10
                self.selected_no = self.num2_won
                self.right_no = self.num2_won
                print(self.selected_no)  # selected No
                print(self.right_no)  # rightNo
                # ==============date time=====================
                now = datetime.datetime.now()
                current_date = now.strftime("%d-%m-%Y")
                current_time = now.strftime('%X')
                print(current_date)
                print(current_time)
                # ==============date time=====================
                add_dta = (
                    self.id_a.get(), self.nme_b.get(), self.eml_c.get(), self.score, self.selected_no, self.right_no,
                    current_date, current_time)
                m = guess_database.add_score(add_dta)  # This statement add score with the player name
                print("hiuh")
                print(m)
                print("hiuh")
                # ==============filling dta table dynamically===================
                ll = guess_database.filling_dta_to_dynamic_table(
                    add_dta)  # This statement add score with the player name does not show the anothe [player detail]
                print("hello")
                print(ll)

    def time_up(self):
        bolo.say("Time Up Try Again ")
        self.n = messagebox.showinfo("Ooops", "Better Luck!!! you Loose!!!")
        bolo.say(f"Right Answer Is {self.num2_won}")
        right_ans = right_answer.Right_answer_Window()
        print("OOPS!!! you LOOSE!", "Chances Left:", self.no_of_guess)
        if self.n:
            bolo.say("You Are Challenger ")
            r = messagebox.showinfo("Score", "You Scored 0")
            self.window.destroy()
            dash_board = game_dashboard.Game_dashboard()
            dash_board.game_dashboard_main()
            # self.m=messagebox.showinfo("Great","Congratulation!!! you won!")
            print(self.id_a.get())
            print(self.nme_b.get())
            print(self.eml_c.get())
            self.score = 0
            self.selected_no = 'NULL'
            print(self.selected_no)  # selected No
            self.right_no = self.num2_won
            print(self.right_no)  # rightNo
            # ==============date time=====================
            now = datetime.datetime.now()
            current_date = now.strftime("%d-%m-%Y")
            current_time = now.strftime('%X')
            print(current_date)
            print(current_time)
            # ==============date time=====================
            add_dta = (
                self.id_a.get(), self.nme_b.get(), self.eml_c.get(), self.score, self.selected_no, self.right_no,
                current_date, current_time)
            m = guess_database.add_score(add_dta)  # This statement add score with the player name
            print("hiuh")
            print(m)
            print("hiuh")
            # ==============filling dta table dynamically===================
            ll = guess_database.filling_dta_to_dynamic_table(
                add_dta)  # This statement add score with the player name does not show the anothe [player detail]
            print("hello")
            print(ll)
        

    
if __name__ == '__main__':
    btn_6_5_8_window=Btn_6_5_8_Window()

    
