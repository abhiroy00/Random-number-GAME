from tkinter import *
import random
from tkinter import messagebox
#import Guess_the_no
import guess_database
import wow_you_won







import bolo
#import Btn_8
#import Btn_9

#-------------------------------------working with buttom Right Answer---------------------------

class Right_answer_Window:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('150x110+1110+160')

        
        #Fetching Random no from database
        print("dhufjahdhh")
        '''m = [i[0] for i in guess_database.insert_rand_no()]
        print(m)'''
        m=guess_database.get_rand_no()#import guess_database
        print(m)
        for i in m:
            print(i)
        for k in i:
            print(k)
        #print(i[0])
        self.num1 = i[1]
        self.num2_won = i[2]
        self.num3 = i[3]
        self.num4 = i[4]
        self.num5 = i[5]
        self.num6 = i[6]
        self.num7 = i[7]
        self.num8 = i[8]
        self.num9 = i[9]
        

        self.no_of_guess=1
        self.max_guess=3

        if  self.num2_won:

            '''self.first_btn = Button(self.window, text=self.Number1, width=5, bg="#9272F4",command=lambda:self.you_loose(),
                                           bd=12,activebackground="#1701A1", relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=150, y=150)'''

            self.second_btn= Button(self.window, text=self.num2_won,width=5, bg="#9272F4",activebackground="#1701A1" ,bd=12,
                                          relief=GROOVE, fg="white", font=("times new roman", 30, "bold")).place(x=0, y=0)
                
    
if __name__ == '__main__':
    right_answer=Right_answer_Window()

    
