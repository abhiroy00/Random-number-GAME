import datetime
now= datetime.datetime.now()
select_date=now.strftime("%d-%m-%Y")
select_time=now.strftime('%X')

print(now)
print(select_date)
print(select_time)

