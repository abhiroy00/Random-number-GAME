from tkinter import *
from tkinter import messagebox
import about_player
import login_page
import Lets_play
import Guess_the_no
import players_score
import rules_for_playing_game


class Game_dashboard:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('850x600+250+20')
        self.window.title('THIS GAME IS DEVELOPED BY AMAN AND ABHISHEK')
        self.window.configure(background="blue")

        #-----------------ALL BACKGROUND IMAGES HAS BEEN MENTION SO YU CAN UNDERSTAND EASILY--------------------
        self.background_img_lft = PhotoImage(file="Images/boll_number_1.png")
        self.img_left = Label(self.window, image=self.background_img_lft).place(x=0, y=0)

    def game_dashboard_main(self):

        self.mainmenu = Menu(self.window)
        self.window.config(menu=self.mainmenu)

        self.pn = Menu(self.mainmenu)
        self.mainmenu.add_cascade(label="PLAY NOW", menu=self.pn)
        self.pn.add_command(label="Lets Play",command= self.play_now)

        self.vw=Menu(self.mainmenu)
        self.mainmenu.add_cascade(label='SCORE',menu=self.vw)
        self.vw.add_command(label='Players Score', command=self.players_score)
        #self.vw.add_command(label='About Product', command=self.goto_about_product_page)
        
        self.lg=Menu(self.mainmenu)
        self.mainmenu.add_cascade(label='LOGOUT',menu=self.lg)
        self.lg.add_command(label='Logout', command=self.logout)

        self.howto = Menu(self.mainmenu)
        self.mainmenu.add_cascade(label="HOW TO PLAY", menu=self.howto)
        self.howto.add_command(label="How To Play Game", command=self.howtoplay)

        self.gr = Menu(self.mainmenu)
        self.mainmenu.add_cascade(label="EXIT", menu=self.gr)
        self.gr.add_command(label="Exit", command=self.exit)
        # self.gr.add_command(label="Add Grocery",command= self.goto_add_grocery_product_page)



    #FUNCTION FOR PLAYING GAME
    def play_now(self):
        self.window.destroy()
        dash_board=Guess_the_no.Main_Window()
        dash_board.save_no()
        
    #FUNCTION FOR CHECKING PLAYERS SCORE
    def players_score(self):
        ask=messagebox.askquestion("Alert","Do You Want To See Score")
        if ask=='yes':
            self.window.destroy()
            score = players_score.Players_score()
            score.score_frame()

            

    #FUNCTION FOR LOGOUT  
    def logout(self):
        m=messagebox.askquestion("Exit","Do You Want To Logout")
        if m=='yes':
            self.window.destroy()
            log=login_page.Login()
            log.main()
            log.window.mainloop()

    #FUNCTION FOR HOW TO PLAY
    def howtoplay(self):
        ask = messagebox.askquestion("Alert", "Learn Clearly")
        if ask == 'yes':
            self.window.destroy()
            rules_for_playing_game.Rules()


   #FUNCTION FOR  EXIT GAME
    def exit(self):
        ask=messagebox.askquestion("Exit","Do You Want To Exit")
        if ask=='yes':
            self.window.destroy()

        

    

if __name__ == '__main__':
    dash_board=Game_dashboard()
    dash_board.game_dashboard_main()



