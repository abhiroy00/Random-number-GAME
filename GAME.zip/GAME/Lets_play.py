from tkinter import *
import random
from tkinter import messagebox
import Guess_the_no

class Lets_Play_Now:
    def __init__(self):
        self.window=Tk()
        self.window.geometry('850x600+250+50')

        self.background_img_lft=PhotoImage(file="Images/guess_window_img.png")
        self.img_left=Label(self.window,image=self.background_img_lft).place(x=0,y=0,height=655)

        self.window.title=Label(self.window,text="GUESS THE NUMBER BETWEEN 00-100",bg="#074463",borderwidth=10,
                                        relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=2).place(x=2,y=6,width=835)

        self.window.title=Label(self.window,text="Click On Play Now",bg="blue",borderwidth=3,
                                        relief=GROOVE,fg="white",font=("times new roman",30,"bold"),pady=1).place(x=250,y=150)

        #self.window.mainloop()

    def coundown(self):
        #self.i=time()
        self.i=30
        self.timer_btn= Button(self.window, text=(" Play Now"),width=10,height=5, bg="pink",activebackground="red" ,bd=4,command=lambda:self.play(),
                                          relief=GROOVE, fg="red", font=("times new roman", 25, "bold")).place(x=300, y=270)
        
        
    def play(self):
        #self.mi = messagebox.askquestion("Alert", "Wants To Play!!!!")
        self.window.destroy()
        dash_board=Guess_the_no.Main_Window()
        dash_board.save_no()

        

            
            
                    

if __name__ == '__main__':
    play_now=Lets_Play_Now()
    play_now.coundown()
    play_now.window.mainloop()
    

    
    
